﻿Console.WriteLine("Informe um número de 1 a 3");
int num = int.Parse(Console.ReadLine());

switch (num)
{
    case 1:
        Console.WriteLine("Bom dia");
        break;
    case 2:
        Console.WriteLine("Boa Tarde");
        break;
    case 3:
        Console.WriteLine("Boa noite");
        break;
